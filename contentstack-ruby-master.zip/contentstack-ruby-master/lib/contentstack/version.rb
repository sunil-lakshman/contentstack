module Contentstack
  VERSION = "0.6.1"
end