module Contentstack
  class Region
    EU='eu'
    US='us'
  end
end